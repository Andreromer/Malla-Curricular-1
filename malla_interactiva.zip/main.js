
function mostrarInfo(nombre, creditos, modulo, el) {
  const nombreEl = document.getElementById('nombre-materia');
  const creditosEl = document.getElementById('creditos');
  const moduloEl = document.getElementById('modulo');

  nombreEl.textContent = nombre;
  creditosEl.textContent = "Créditos: " + creditos;
  moduloEl.textContent = "Módulo: " + modulo;

  // Alternar tachado
  el.classList.toggle('tachada');
}
